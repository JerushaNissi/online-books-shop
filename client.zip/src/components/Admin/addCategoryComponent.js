import React, { Component } from "react";
import UserService from "../../services/user.service";



export default class AddCategory extends Component {
    constructor(props) {
        super(props);


        this.onChangeCategoryname = this.onChangeCategoryname.bind(this);

        this.onChangeDescription = this.onChangeDescription.bind(this);


        this.saveCategory = this.saveCategory.bind(this);
        // this.newBook = this.newBook.bind(this);

        this.state = {
            id: null,
            categoryname: "",
            description: "",
            submitted: false
        };

    }


    onChangeCategoryname(e) {
        this.setState({
            categoryname: e.target.value
        });
    }

    onChangeDescription(e) {
        this.setState({
            description: e.target.value
        });
    }

    saveCategory() {
        var data = {

            categoryname: this.state.categoryname,

            description: this.state.description
        };

        UserService.createCategory(data)
            .then(res => {
                this.setState({

                    categoryname: res.data.categoryname,

                    description: res.data.description,
                    submitted: true
                });
                console.log(res.data);
            })
            .catch(e => {
                console.log(e);
            });
        this.props.history.push("/viewCategory");
        console.log("added");
    }




    render() {
        const text = {
            width: "100%"
        }
        return (
            <div className="submit-form">
                {this.state.submitted ? (
                    <div>
                        <h4>You submitted successfully!</h4>
                        {/* <button className="btn btn-success" onClick={this.newBook}>
                            Click to go back
                        </button> */}
                    </div>
                ) : (
                        <div className="container">
                            <div className="w-75 mx-auto shadow p-5">
                                <h2 className="text-center mb-4">Add Category</h2>
                                <form>

                                    <div className="form-group">
                                        <label >Category Name</label>
                                        <input
                                            type="text"
                                            className="form-control form-control-lg"
                                            placeholder="Enter category"
                                            id="categoryname"
                                            name="categoryname"
                                            required
                                            value={this.state.categoryname}
                                            onChange={this.onChangeCategoryname}

                                        />
                                    </div>
                                    <div className="form-group">
                                        <label>Description</label>
                                        <input
                                            type="text"
                                            className="form-control form-control-lg"
                                            placeholder="description"
                                            id="descrition"
                                            name="description"
                                            value={this.state.description}
                                            onChange={this.onChangeDescription}
                                        />
                                    </div>
                                    <button className="btn btn-warning btn-block" onClick={this.saveCategory}>Submit</button>
                                </form>
                            </div>
                        </div>
                    )}
            </div>
        );
    }

}

