import React, { Component } from "react";
import UserService from "../../services/user.service";

export default class EditCategory extends Component {
    constructor(props) {
        super(props);
        this.onChangeCategoryName = this.onChangeCategoryName.bind(this);
        this.onChangeDescription = this.onChangeDescription.bind(this);
        this.updateCategory = this.updateCategory.bind(this);
        this.getCategory = this.getCategory.bind(this);

        this.state = {
            currentCategory: {
                categoryname: "",
                description: "",
            },
            message: ""
        };
    }

    componentDidMount() {
        this.getCategory(this.props.match.params.id);
    }



    onChangeCategoryName(e) {
        const categoryname = e.target.value;

        this.setState(function (prevState) {
            return {
                currentCategory: {
                    ...prevState.currentCategory,
                    categoryname: categoryname
                }
            };
        });
    }

    onChangeDescription(e) {
        const description = e.target.value;

        this.setState(function (prevState) {
            return {
                currentCategory: {
                    ...prevState.currentCategory,
                    description: description
                }
            };
        });
    }


    getCategory(id) {
        UserService.categoryById(id)
            .then(res => {
                this.setState({
                    currentCategory: res.data
                });
                console.log(res.data);
            })
            .catch(e => {
                console.log(e);
            });
    }



    updateCategory() {
        UserService.editCategory(this.state.currentCategory._id,
            this.state.currentCategory)
            .then(res => {
                console.log(res.data);
                this.setState({
                    message: alert("The Category got updated successfully")
                });
            })

            .catch(e => {
                console.log(e);
            });
        this.props.history.push("/viewCategory")
    }



    render() {
        const { currentCategory } = this.state;

        return (
            <div className="container">
                <div className="w-75 mx-auto shadow p-5">
                    <h2 className="text-center mb-4">Edit A User</h2>
                    <form>

                        <div className="form-group">
                            <input
                                type="text"
                                className="form-control form-control-lg"
                                placeholder="Enter Your categoryname"
                                name="categoryname"
                                value={currentCategory.categoryname}
                                onChange={this.onChangeCategoryName}
                            />
                        </div>
                        <div className="form-group">
                            <input
                                type="text"
                                className="form-control form-control-lg"
                                placeholder="Enter  description"
                                name="description"
                                value={currentCategory.description}
                                onChange={this.onChangeDescription}
                            />
                        </div>
                        <button className="btn btn-warning btn-block" onClick={this.updateCategory}>Update Category</button>
                    </form>
                </div>
            </div>
        );
    }
}
