import React, { Component } from "react";
import UserService from "../../services/user.service";



export default class AddAuthor extends Component {
    constructor(props) {
        super(props);


        this.onChangeAuthorName = this.onChangeAuthorName.bind(this);

        this.onChangeAuthorPlace = this.onChangeAuthorPlace.bind(this);


        this.saveCategory = this.saveCategory.bind(this);
        // this.newBook = this.newBook.bind(this);

        this.state = {
            id: null,
            authorname: "",
            authorplace: "",
            submitted: false
        };

    }


    onChangeAuthorName(e) {
        this.setState({
            authorname: e.target.value
        });
    }









    onChangeAuthorPlace(e) {
        this.setState({
            authorplace: e.target.value
        });
    }




    saveCategory() {
        var data = {

            authorname: this.state.authorname,

            authorplace: this.state.authorplace
        };

        UserService.createAuthor(data)
            .then(res => {
                this.setState({

                    authorname: res.data.authorname,

                    authorplace: res.data.authorplace,
                    submitted: true
                });
                console.log(res.data);
            })
            .catch(e => {
                console.log(e);
            });
        this.props.history.push("/viewAuthor");
    }




    render() {
        const text = {
            width: "100%"
        }
        return (
            <div className="submit-form">
                {this.state.submitted ? (
                    <div>
                        <h4>You submitted successfully!</h4>
                        {/* <button className="btn btn-success" onClick={this.newBook}>
                            Click to go back
                        </button> */}
                    </div>
                ) : (
                        <div className="container">
                            <div className="w-75 mx-auto shadow p-5">
                                <h2 className="text-center mb-4">Add Author</h2>
                                <form>

                                    <div className="form-group">
                                        <label >Author Name</label>
                                        <input
                                            type="text"
                                            className="form-control form-control-lg"
                                            placeholder="Enter Author Name"
                                            id="authorname"
                                            name="authorname"
                                            required
                                            value={this.state.authorname}
                                            onChange={this.onChangeAuthorName}

                                        />
                                    </div>
                                    <div className="form-group">
                                        <label>Author Place</label>
                                        <input
                                            type="text"
                                            className="form-control form-control-lg"
                                            placeholder="authorplace"
                                            id="authorplace"
                                            name="authorplace"
                                            value={this.state.authorplace}
                                            onChange={this.onChangeAuthorPlace}
                                        />
                                    </div>
                                    <button className="btn btn-warning btn-block" onClick={this.saveCategory}>Submit</button>
                                </form>
                            </div>
                        </div>
                    )}
            </div>
        );
    }

}

