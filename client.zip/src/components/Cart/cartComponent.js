import React from "react";
//import Auth from "../../actions/authActions";
import Axios from "axios";

// import { getCurrentUser } from "../services/auth-header";
import AuthService from "../../services/auth.service";
//import Navbar from "../layout/Navbar";
class Cart extends React.Component {

    // state = {
    //     searchItem: "",
    //     display: true,
    //     result: [],
    //     message: "",
    //     totalPrice: 0,

    // };

    constructor(props) {
        super(props);
        this.state = {
            cartItems: [],
            message: "",
            totalPrice: 0,
            displayCart: false,
            currentUser: AuthService.getCurrentUser(),
            searchItem: "",
            display: true,
            result: [],
            message: "",
            totalPrice: 0,
        };
        this.checkout = this.checkout.bind(this);

    }

    componentDidMount() {
        if (!this.state.currentUser) {
            this.props.history.push("/login");
        } else {

        Axios.get(
            `http://localhost:8080/cart/getCartItems?username=${this.state.currentUser.username}`
        ).then((res) => {
            console.log(this.state.currentUser.username);
            if (res.data.message === true) {
                this.setState({ cartItems: res.data.cartItems }, () => {
                    let sum = 0, total;
                    this.state.cartItems.map((cartItem) => {
            
                        total = cartItem.quantity * cartItem.book.price;
                        sum = sum + total;

                        return sum;
                    });

                    // console.log(sum);
                    this.setState({ totalPrice: sum });
                    // console.log(this.state.totalAmount);
                });
            } else {
                this.setState({ message: res.data.message });
            }
        });
    }
}

    logoutHandler = () => {
        this.auth.logout();
    };

    checkout = () => {

        // browserHistory.push("/checkout");
        this.props.history.push("/checkout");
        console.log("this works");
    };

    decrementHandler = (id) => {
        console.log(id);
        Axios.post(
            `http://localhost:8080/cart/dec?id=${id}&username=${this.state.currentUser.username}`
        ).then((res) => {
            console.log(res.data.message);
            if (res.data.message === true) {
                this.setState({ message: `decremented Successfully` });
                window.location.reload();
            } else {
                this.setState({
                    message: `Unable to do the action please try again later`,
                });
                alert(this.state.message);
            }
        });
    };

    incrementHandler = (id) => {
        console.log(id);
        Axios.post(
            `http://localhost:8080/cart/inc?id=${id}&username=${this.state.currentUser.username}`
        ).then((res) => {
            console.log(res.data.message);
            if (res.data.message === true) {
                this.setState({ message: `incremented Successfully` });
                window.location.reload();
            } else {
                this.setState({
                    message: `Unable to do the action please try again later`,
                });
                alert(this.state.message);
            }
        });
    };

    deletecartItem = (id) => {
        console.log(id);
        Axios.post(
            `http://localhost:8080/cart/deleteBook?id=${id}&username=${this.state.currentUser.username}`
        ).then((res) => {
            console.log(res.data.message);
            if (res.data.message === true) {
                this.setState({ message: `Deleted Successfully` });
                window.location.reload();
            } else {
                this.setState({
                    message: `Unable to do the action please try again later`,
                });
                alert(this.state.message);
            }
        });
    };

    error = () => {
        alert("Add more than 1 item to buy");
        this.props.history.push("/");
    }

    continueShopping = () => {
        this.props.history.push("/");
    }

    render() {
        return (
            <div className="container-fluid">
                <div className="row">
                    <div className="col-lg-10">
                        <p className="ml-5 mt-5">

                            <h3 id="text1">Shopping Cart</h3>
                            <button className="btn btn-primary" style={{ width: "40%", marginLeft: "80%" }} onClick={this.continueShopping}>Continue Shopping</button>
                        </p>
                        {(!this.state.cartItems.length) ?
                            <>
                                <h1>No Cart Items</h1>
                            </> :

                            <>
                                <div className="col-lg-8">
                                    {this.state.cartItems.map((cartItem, index) => {
                                        return (
                                            <div key={index} class="card">
                                                <div className="row">
                                                    <div className="col-sm-3">
                                                        <img src={`http://localhost:8080/${cartItem.book.productImage}`} className="card-img-top" alt="..." />
                                                    </div>

                                                    <div className="col-sm-9">
                                                        <div><b>Book Name:</b> {cartItem.book.title}</div>
                                                        <div><b>Category:</b> {cartItem.book.category}</div>
                                                        <div><b>Price:</b> {cartItem.book.price}</div>
                                                        <div><b>Author:</b> {cartItem.book.author}</div>
                                                        <div><b>Publisher:</b> {cartItem.book.publisher}</div><br />

                                                        <div style={{ width: "200px" }}>
                                                            <div className="row">
                                                                <div className="col-lg-8">
                                                                    <div className="input-group">

                                                                        <div class="input-group-prepend">
                                                                            <span
                                                                                className="input-group-text"
                                                                                type="button"
                                                                                onClick={() =>
                                                                                    this.decrementHandler(cartItem.book._id)
                                                                                }

                                                                            >
                                                                                <b >-</b>
                                                                            </span>
                                                                        </div> &nbsp;

                                                    <input
                                                                            type="text"
                                                                            className="border-0 text-center "
                                                                            value={cartItem.quantity}
                                                                            style={{ width: "35px" }}
                                                                        /> &nbsp;

                                                    <div class="input-group-append">
                                                                            <span
                                                                                className="input-group-text"
                                                                                type="button"
                                                                                onClick={() =>
                                                                                    this.incrementHandler(cartItem.book._id)
                                                                                }

                                                                            >
                                                                                <b>+</b>
                                                                            </span>
                                                                        </div>

                                                                    </div>
                                                                </div>

                                                                <div className="col-lg-4">
                                                                    <button
                                                                        className="btn btn-danger "
                                                                        type="button"
                                                                        onClick={() => this.deletecartItem(cartItem.book._id)}
                                                                    >
                                                                        <i
                                                                            className="fa fa-trash"
                                                                            aria-hidden="true"
                                                                            style={{ margin: "0px" }}
                                                                        ></i>
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        );
                                    })}
                                    <div>
                                        {" "}
                                        <div colspan="6" className="col-sm-3 badge badge-lg badge-primary" style={{ textAlign: "center",width:"20%" }}>
                                            total :{" "}
                                            <b className="text-danger">{this.state.totalPrice}</b>
                                        </div>
                                    </div>
                                </div>




                                <hr />

                                <div className="col-xl-10 outercard">
                                    <div className="card w-75 m-5 innercard">              {/*<div className="card-custom w-75 m-5 border innercard"></div> */}
                                        <div className="card-body card-custom-bg">

                                            <div className="card-custom-bg">
                                                Subtotal ({this.state.cartItems.length} items) : ₹
                                            <b>{this.state.totalPrice}</b>
                                            </div>

                                            <button
                                                className="btn btn-custom-cartbuy btn-primary form-control mt-4"
                                                type="button"
                                                onClick={() => this.checkout()}
                                            >
                                                <a href="/checkout" style={{ color: "white" }}> Buy Now </a>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </>}
                    </div>
                </div>
            </div>
        );
    }
}

export default Cart;










