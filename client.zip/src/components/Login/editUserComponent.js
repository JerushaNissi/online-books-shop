// import React, { useState, useEffect } from "react";
// import axios from "axios";
// import { useHistory, useParams } from "react-router-dom";
// import AuthService from "../../services/auth.service";

// const EditUser = () => {
//     let history = useHistory();
//     const { id } = useParams();
//     const [user, setUser] = useState({

//         username: "",
//         email: "",

//     });

//     const { username, email, } = user;
//     const onInputChange = e => {
//         setUser({ ...user, [e.target.name]: e.target.value });
//     };

//     useEffect(() => {
//         loadUser();
//     }, []);

//     const onSubmit = async e => {
//         e.preventDefault();
//         await axios.put(`http://localhost:8080/api/update/user/${id}`, user);
//         history.push("/login");
//     };

//     if (onSubmit === true) {
//         AuthService.logout();
//     }

//     const loadUser = async () => {
//         const result = await axios.get(`http://localhost:8080/api/get/user/${id}`);
//         setUser(result.data);
//     };
//     return (
//         <div className="container" >
//             <div className="w-75 mx-auto shadow p-5" id="updateuser">
//                 <h2 className="text-center mb-4">Edit A User</h2>
//                 <form onSubmit={e => onSubmit(e)}>

//                     <div className="form-group">
//                         <input
//                             type="text"
//                             className="form-control form-control-lg"
//                             placeholder="Enter Your Username"
//                             name="username"
//                             value={username}
//                             onChange={e => onInputChange(e)}
//                         />
//                     </div>
//                     <div className="form-group">
//                         <input
//                             type="email"
//                             className="form-control form-control-lg"
//                             placeholder="Enter Your E-mail Address"
//                             name="email"
//                             value={email}
//                             onChange={e => onInputChange(e)}
//                         />
//                     </div>
//                     <button className="btn btn-warning btn-block">Update User</button>
//                 </form>
//             </div>
//         </div>
//     );
// };

// export default EditUser;

import React, { Component } from "react";
import UserService from "../../services/user.service";

export default class EditUser extends Component {
    constructor(props) {
        super(props);
        this.onChangeUsername = this.onChangeUsername.bind(this);
        this.onChangeEmail = this.onChangeEmail.bind(this);
        this.updateUser = this.updateUser.bind(this);
        this.getUser = this.getUser.bind(this);
        this.logout = this.logout.bind(this);
        this.state = {
            currentUser: {
                username: "",
                email: ""
            },
            message: ""
        };
    }

    componentDidMount() {
        this.getUser(this.props.match.params.id);
    }

    logout() {
        localStorage.removeItem("user");
        this.props.history.push("/login");
    }

    onChangeUsername(e) {
        const username = e.target.value;

        this.setState(function (prevState) {
            return {
                currentUser: {
                    ...prevState.currentUser,
                    username: username
                }
            };
        });
    }

    onChangeEmail(e) {
        const email = e.target.value;

        this.setState(function (prevState) {
            return {
                currentUser: {
                    ...prevState.currentUser,
                    email: email
                }
            };
        });
    }


    getUser(id) {
        UserService.getById(id)
            .then(res => {
                this.setState({
                    currentUser: res.data
                });
                console.log(res.data);
            })
            .catch(e => {
                console.log(e);
            });
    }



    updateUser() {
        UserService.updateUser(this.state.currentUser._id,
            this.state.currentUser)
            .then(res => {
                console.log(res.data);
                this.setState({
                    message: alert("The User got updated successfully")
                });
                this.logout();


            })

            .catch(e => {
                console.log(e);
            });
        
    }



    render() {
        const { currentUser } = this.state;

        return (
            <div className="container">
                <div className="w-75 mx-auto shadow p-5">
                    <h2 className="text-center mb-4">Edit A User</h2>
                    <form>

                        <div className="form-group">
                            <input
                                type="text"
                                className="form-control form-control-lg"
                                placeholder="Enter Your Username"
                                name="username"
                                value={currentUser.username}
                                onChange={this.onChangeUsername}
                            />
                        </div>
                        <div className="form-group">
                            <input
                                type="email"
                                className="form-control form-control-lg"
                                placeholder="Enter Your E-mail Address"
                                name="email"
                                value={currentUser.email}
                                onChange={this.onChangeEmail}
                            />
                        </div>
                        <button className="btn btn-warning btn-block" onClick={this.updateUser}>Update User</button>
                    </form>
                </div>
            </div>
        );
    }
}

