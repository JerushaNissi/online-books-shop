import React from "react";
import axios from "axios";
//import { getUserName } from "../../services/auth-header";
import AuthService from "../../services/auth.service";

class ViewDetails extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            books: [],
            currentUser: AuthService.getCurrentUser(),
        };
        this.goBack = this.goBack.bind(this);
        this.addToCartHandler = this.addToCartHandler.bind(this);
    }

    componentDidMount() {
        var id = this.props.match.params.id;
        console.log(id);
        axios.get(`http://localhost:8080/api/books/${id}`).then((res) => {
            this.setState({
                books: res.data
            });
            console.log(res.data);
        })
            .catch(e => {
                console.log(e);
            });
    }


    addToCartHandler = (id) => {
        console.log(id);
        axios.post(
            `http://localhost:8080/cart/addBook?id=${id}&username=${this.state.currentUser.username}`
        ).then((res) => {
            console.log(this.state.currentUser.username);
            console.log(res.data.message);
            // if (this.state.currentUser.username === '') {
            //     this.props.history.push('/login');
            // }
            if (res.data.message === true) {
                this.props.history.push(`/cart`);
            } else {
                this.setState({
                    message: `Unable to add to cart please try again later`,
                });
                alert(this.state.message);
            }
        });
    };


    goBack = () => {
        this.props.history.push("/");
    };

    render() {
        const { books,currentUser } = this.state;
        
        return (
            <div className="container">


                <h2>{books.title} </h2>
                <hr />
                <div className="card" id="cardimage">
                    <div className="row">
                        <div className="col-sm-3">
                            <img src={`http://localhost:8080/${books.productImage}`} className="card-img-top" alt="..." />
                        </div>
                        <div className="card-body col-sm-9">
                            {/* <p className="card-text "><strong>Book Id:</strong>&nbsp;{books.id}</p> */}
                            <p className="card-text "><strong>Book Title:</strong>&nbsp;{books.title}</p>
                            <p className="card-text"><strong>Book Category:</strong>&nbsp;{books.category}</p>
                            <p className="card-text"><strong>Book Price:</strong>&nbsp;{books.price}</p>
                            <p className="card-text"><strong>Book Author:</strong>&nbsp;{books.author}</p>

                            <p className="card-text"><strong>Book Publisher:</strong>&nbsp;{books.publisher}</p>
                            <p className="card-text"><strong>Book Description:</strong>&nbsp;{books.description}</p>
                            {!currentUser ?
                                            <>
                                               <button className="btn btn-success" onClick={this.goBack} style={{ borderRadius: 15 }}>Go back to products</button> &nbsp;
                                              
                                            </> : <>
                                            <button className="btn btn-success" onClick={this.goBack} style={{ borderRadius: 15 }}>Go back to products</button> &nbsp;
                                            <button className="btn btn-warning" onClick={() => this.addToCartHandler(books.id)} style={{ borderRadius: 15 }}>Add to cart</button>&nbsp;
                                            </>

                            }
                            
                                

                            </div>
                    </div>
                </div>
            </div>


        );
    }
}

export default ViewDetails;


