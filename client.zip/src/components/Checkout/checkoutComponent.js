import React, { Component } from "react";
import Axios from "axios";
import AuthService from "../../services/auth.service";

const validateForm = (errors) => {
    let valid = true;

    return valid;
};
export default class Checkout extends Component {
    constructor(props) {
        super(props);
        this.state = {
            cartItems: [],
            currentUser: AuthService.getCurrentUser(),
            cardNumber: "",
            expityMonth: "",
            fname: "",
            lname: "",
            cvCode: "",
            totalAmount: 0,
            errors: {
                cardNumber: "",
                expityMonth: "",
                cvCode: "",
                fname: "",
                lname: ""
            },
        };
    }

    handleChange = (event) => {
        event.preventDefault();
    };

    handleSubmit = (event) => {
        event.preventDefault();
        if (validateForm(this.state.errors)) {
            console.info("Valid Form");
            this.props.history.replace("/thankYou");
        } else {
            console.error("Invalid Form");
        }
    };

    componentDidMount() {

        Axios.get(
            `http://localhost:8080/cart/getCartItems?username=${this.state.currentUser.username}`
        ).then((res) => {
            console.log(this.state.currentUser.username);
            if (res.data.message === true) {
                this.setState({ cartItems: res.data.cartItems }, () => {
                    let sum = 0;
                    this.state.cartItems.map((cartItem) => {
                        // console.log(cartItem.book.price);
                        sum = sum + (cartItem.book.price * cartItem.quantity);

                        return sum;
                    });

                    // console.log(sum);
                    this.setState({ totalPrice: sum });
                    // console.log(this.state.totalAmount);
                });
            } else {
                this.setState({ message: res.data.message });
            }
        });
    }
    render() {
        //console.log(this.state.totalAmount);
        // const { errors } = this.state;
        return (
            <div className="container content">
                <div className="row ">
                    <div className="col-8">
                        <div className="panel panel-default">
                            <div className="panel-heading">
                                <h3><strong style={{ color: "white" }}>
                                    Fill out your Details to pay<hr></hr>
                                </strong>
                                </h3>
                            </div>
                            <div className="panel-body">
                                <form onSubmit={this.handleSubmit}>
                                    <div className="row">
                                        <div className="col-6">
                                            <div className="form-group">
                                                <label htmlFor="fname" style={{ color: "white" }}>First Name</label>
                                                <div className="col-12">
                                                    <input
                                                        type="text"
                                                        className="form-control"
                                                        id="fnam"
                                                        placeholder="first name"
                                                        required
                                                        onChange={this.handleChange}
                                                    />

                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-6 ">
                                            <div className="form-group">
                                                <label htmlFor="lname" style={{ color: "white" }}>Last Name</label>
                                                <input
                                                    type="password"
                                                    className="form-control"
                                                    id="lname"
                                                    placeholder="last name"
                                                    required
                                                    onChange={this.handleChange}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="email" style={{ color: "white" }}>Email</label>
                                        <div className="input-group">
                                            <input
                                                type="email"
                                                className="form-control"
                                                id="email"
                                                placeholder="enter correct email "
                                                required
                                                onChange={this.handleChange}
                                            />
                                        </div>
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="address" style={{ color: "white" }}>Address</label>
                                        <div className="input-group">
                                            <textarea

                                                className="form-control"
                                                id="address"
                                                placeholder="Enter your full address "
                                                required
                                                onChange={this.handleChange}
                                            />
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-4" >
                                            <div className="form-group-inline">
                                                <label htmlFor="city" style={{ color: "white" }}>City</label>
                                                <div className="col-12 pl-ziro">
                                                    <input
                                                        type="text"
                                                        className="form-control"
                                                        id="city"
                                                        placeholder="city"
                                                        required
                                                        onChange={this.handleChange}
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-4 ">
                                            <div className="form-group">
                                                <label htmlFor="state" style={{ color: "white" }}>State</label>
                                                <input
                                                    type="text"
                                                    className="form-control"
                                                    id="state"
                                                    placeholder="state"
                                                    required
                                                    onChange={this.handleChange}
                                                />
                                            </div>
                                        </div>
                                        <div className="col-4 ">
                                            <div className="form-group">
                                                <label htmlFor="pin" style={{ color: "white" }}>Pin Code</label>
                                                <input
                                                    type="text"
                                                    className="form-control"
                                                    id="pin"
                                                    placeholder="pin code"
                                                    required
                                                    onChange={this.handleChange}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="cardNumber" style={{ color: "white" }}>CARD NUMBER</label>
                                        <div className="input-group">
                                            <input
                                                type="text"
                                                className="form-control"
                                                id="cardNumbe"
                                                placeholder="xxxx xxxx xxxx xxxx"
                                                required
                                                onChange={this.handleChange}
                                            />
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-8">
                                            <div className="form-group-inline">
                                                <label htmlFor="endate" style={{ color: "white" }}>EXPIRY DATE</label>
                                                <div className="col-12 pl-ziro">
                                                    <input
                                                        type="text"
                                                        className="form-control"
                                                        id="endate"
                                                        placeholder="mm/yyyy"
                                                        required
                                                        onChange={this.handleChange}
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-4 ">
                                            <div className="form-group">
                                                <label htmlFor="cvCode" style={{ color: "white" }}>CVV CODE</label>
                                                <input
                                                    type="password"
                                                    className="form-control"
                                                    id="cvCod"
                                                    placeholder="CVV"
                                                    required
                                                    onChange={this.handleChange}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                    <hr></hr>
                                    <div className="submit">
                                        <button className="btn btn-success btn-lg btn-block">
                                            Pay Rs.{this.state.totalPrice}
                                        </button>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                    <div className="col-4">
                        <div class="card">
                            <div class="card-header">
                                <div class="d-inline h4">Order Details</div>
                                <div class="d-inline float-right"></div>
                            </div>
                            {this.state.cartItems.map((cartItem, index) => {
                                return (
                                    <div class="card-body">
                                        <dl class="row">
                                            <dd class="col-sm-4">Title</dd>
                                            <dt class="col-sm-8">{cartItem.book.title}</dt>
                                            <dd class="col-sm-4">Price</dd>
                                            <dt class="col-sm-8">{cartItem.book.price}</dt>
                                        </dl>
                                        <hr />
                                    </div>
                                );
                            })}
                            <dl class="row">
                                <dd class="col-sm-4">Total Price</dd>
                                <dt class="col-sm-8">{this.state.totalPrice} <br />

                                </dt>
                            </dl>
                        </div>

                    </div>
                   
                </div>
            </div>
        );
    }
}
