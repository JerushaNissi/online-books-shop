import React, { Component } from "react";
import { Switch, Route, Link, Redirect } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import Dropdown from "react-bootstrap/Dropdown";
import "./App.css";

import AuthService from "./services/auth.service";
import UserService from "./services/user.service";

import Login from "./components/Login/loginPageComponent";
import Register from "./components/Login/registerComponent";
import Home from "./components/Home/homeComponent";
import Profile from "./components/Login/profiledetailsComponent";
import BoardUser from "./components/User/userComponent";
// import BoardAdmin from "./components/Admin/administratorComponnet";
import Cart from "./components/Cart/cartComponent";
import AddBook from "./components/Admin/addBookComponent";
import BooksEdit from "./components/Admin/booksEditComponent";
import Book from "./components/Admin/bookComponent";
import Checkout from "./components/Checkout/checkoutComponent";
import ThankYou from "./components/Checkout/thankyouComponent";
import ViewDetails from "./components/Checkout/viewDetailsComponent";
import BookList from "./components/Books/bookListComponent";
import CssBook from "./components/Books/cssComponent";
import HtmlBook from "./components/Books/htmlComponent";
import Author1 from "./components/Author/author1Component";
import Author2 from "./components/Author/author2Component";
import Author3 from "./components/Author/author3Component";
import EditUser from "./components/Login/editUserComponent";
import Footer2 from "./components/Footer/Footer";
import ReactBook from "./components/Books/reactComponent";
import JavaBook from "./components/Books/javaComponent";
import PythonBook from "./components/Books/pythonComponent";
import AddCategory from "./components/Admin/addCategoryComponent";
import AddAuthor from "./components/Admin/addAuthorComponent";
import EditCategory from "./components/Admin/editCategoryComponent";
import EditAuthor from "./components/Admin/editAuthorComponent";
import ViewCategory from "./components/Admin/viewCategoryComponent";
import ViewAuthor from "./components/Admin/viewAuthorComponent";

/*Icons */
import { GiShoppingCart } from "react-icons/gi";
import { GiBookshelf } from "react-icons/gi";

class App extends Component {
  constructor(props) {
    super(props);
    this.logOut = this.logOut.bind(this);

    this.state = {
      books: [],
      showAdminBoard: false,
      currentUser: undefined,
      cart: [],
      searchTitle: "",
    };
  }

  componentDidMount() {
    const user = AuthService.getCurrentUser();

    if (user) {
      this.setState({
        currentUser: user,

        showAdminBoard: user.roles.includes("ROLE_ADMIN"),
      });
    }
  }

  logOut() {
    AuthService.logout();
  }

  render() {
    const { currentUser, showAdminBoard, showUser } = this.state;
    console.log(currentUser);

    return (
      <div className="app">
        <nav className="navbar navbar-expand  fixed-top" id="mainNav">
          <Link to={"/"} className="navbar-brand">
            Pro Books
          </Link>

          <div className="navbar-nav mr-auto">
            <li className="nav-item">
              <Link to={"/"} className="nav-link">
                Home
              </Link>
            </li>

            {showAdminBoard ? (
              <div className="navbar-nav ml-auto">
                <Dropdown>
                  <Dropdown.Toggle
                    variant="none"
                    id="dropdown-basic"
                    className="nav-item"
                  >
                    Category
                  </Dropdown.Toggle>

                  <Dropdown.Menu>
                    <Dropdown.Item href="/addcategory" className="link">
                      Add Category
                    </Dropdown.Item>
                    <Dropdown.Item href="/viewCategory" className="link">
                      View Category
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown>

                <Dropdown>
                  <Dropdown.Toggle
                    variant="none"
                    id="dropdown-basic"
                    className="nav-item"
                  >
                    Author
                  </Dropdown.Toggle>

                  <Dropdown.Menu>
                    <Dropdown.Item href="/addauthor" className="link">
                      Add Author
                    </Dropdown.Item>
                    <Dropdown.Item href="/viewAuthor" className="link">
                      View Author
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown>
              </div>
            ) : (
              <div className="navbar-nav ml-auto">
                <Dropdown>
                  <Dropdown.Toggle
                    variant="none"
                    id="dropdown-basic"
                    className="nav-item"
                  >
                    Category
                  </Dropdown.Toggle>

                  <Dropdown.Menu>
                    <Dropdown.Item href="/book" className="link">
                      All Books
                    </Dropdown.Item>
                    <Dropdown.Item href="/html" className="link">
                      HTML
                    </Dropdown.Item>
                    <Dropdown.Item href="/css" className="link">
                      CSS
                    </Dropdown.Item>
                    <Dropdown.Item href="/react" className="link">
                      React
                    </Dropdown.Item>
                    <Dropdown.Item href="/python" className="link">
                      python
                    </Dropdown.Item>
                    <Dropdown.Item href="/java" className="link">
                      java
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown>

                <Dropdown>
                  <Dropdown.Toggle
                    variant="none"
                    id="dropdown-basic"
                    className="nav-item"
                  >
                    Author
                  </Dropdown.Toggle>

                  <Dropdown.Menu>
                    <Dropdown.Item href="/srinivas" className="link">
                      Srinivas
                    </Dropdown.Item>
                    <Dropdown.Item href="/jonduckett" className="link">
                      Jon Duckett
                    </Dropdown.Item>
                    <Dropdown.Item href="/timberners" className="link">
                      Tim Berners
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown>
              </div>
            )}

            {showAdminBoard && (
              <li className="nav-item">
                <Link to={"/books"} className="nav-link">
                  Books
                </Link>
              </li>
            )}

            {/* {showAdminBoard && (
              <li className="nav-item">
                <Link to={"/admin"} className="nav-link">
                  Admin Board
                </Link>
              </li>
            )} */}

            {showAdminBoard && (
              <li className="nav-item">
                <Link to={"/add"} className="nav-link">
                  Add Books
                </Link>
              </li>
            )}

            {showAdminBoard && (
              <li className="nav-item">
                <Link to={"/user"} className="nav-link">
                  User
                </Link>
              </li>
            )}
          </div>

          {currentUser ? (
            <div className="navbar-nav ml-auto">
              <li className="nav-item">
                <Link to={"/profile"} className="nav-link">
                  {currentUser.username}
                </Link>
              </li>
              <li className="nav-item">
                <a href="/login" className="nav-link" onClick={this.logOut}>
                  LogOut
                </a>
              </li>

              <li className="nav-item">
                <Link to={"/cart"} className="nav-link">
                  <GiShoppingCart style={{ fontSize: 32, color: "white" }} />
                </Link>
              </li>
            </div>
          ) : (
            <div className="navbar-nav ml-auto">
              <li className="nav-item">
                <Link to={"/login"} className="nav-link">
                  Login
                </Link>
              </li>

              <li className="nav-item">
                <Link to={"/register"} className="nav-link">
                  {/* <i class="fa fa-user-plus" aria-hidden="true" style={{ fontSize: 32, color: "blue" }}></i> */}
                  Sign Up
                </Link>
              </li>
            </div>
          )}
        </nav>
        <br />
        <br />
        <br />

        <div className="container mt-3">
          <Switch>
            <Route exact path={["/", "/book"]} component={Home} />
            <Route exact path="/book" component={BookList} />
            <Route exact path="/books" component={BooksEdit} />
            <Route exact path="/books/:id" component={Book} />
            <Route exact path="/edit/:id" component={EditUser} />
            <Route exact path="/editcategory/:id" component={EditCategory} />
            <Route exact path="/editauthor/:id" component={EditAuthor} />
            <Route exact path="/add" component={AddBook} />
            <Route exact path="/login" component={Login} />
            <Route exact path="/register" component={Register} />
            <Route exact path="/profile" component={Profile} />
            <Route path="/user" component={BoardUser} />
            {/* <Route path="/admin" component={BoardAdmin} /> */}
            <Route path="/cart" component={Cart} />
            <Route path="/checkout" component={Checkout} />
            <Route path="/thankyou" component={ThankYou} />
            <Route path="/view/:id" component={ViewDetails} />
            <Route path="/css" component={CssBook} />
            <Route path="/react" component={ReactBook} />
            <Route path="/html" component={HtmlBook} />
            <Route path="/java" component={JavaBook} />
            <Route path="/python" component={PythonBook} />
            <Route path="/srinivas" component={Author1} />
            <Route path="/jonduckett" component={Author2} />
            <Route path="/timberners" component={Author3} />
            <Route path="/addcategory" component={AddCategory} />
            <Route path="/addauthor" component={AddAuthor} />
            <Route path="/viewCategory" component={ViewCategory} />
            <Route path="/viewAuthor" component={ViewAuthor} />
          </Switch>
        </div>

        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <Footer2 />
      </div>
    );
  }
}

export default App;
